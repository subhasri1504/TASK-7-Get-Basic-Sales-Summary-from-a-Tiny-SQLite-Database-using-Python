#!/usr/bin/env python3
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

DB_PATH = Path(__file__).parent / "sales_data.db"

def main():
    conn = sqlite3.connect(DB_PATH)
    print(f"Connected to: {DB_PATH}")

    query = """
        SELECT 
            product,
            SUM(quantity) AS total_qty,
            SUM(quantity * price) AS revenue
        FROM sales
        GROUP BY product
        ORDER BY revenue DESC
    """
    df = pd.read_sql_query(query, conn)

    print("\n=== Revenue by Product ===")
    print(df)

    totals_q = "SELECT SUM(quantity) AS total_qty, SUM(quantity*price) AS total_revenue FROM sales"
    totals = pd.read_sql_query(totals_q, conn)
    print("\n=== Overall Totals ===")
    print(totals)

    plt.figure()
    plt.bar(df["product"], df["revenue"])
    plt.xlabel("Product")
    plt.ylabel("Revenue")
    plt.title("Revenue by Product")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    out_path = Path(__file__).parent / "sales_chart.png"
    plt.savefig(out_path)
    print(f"\nSaved chart to: {out_path}")

    conn.close()

if __name__ == "__main__":
    main()
